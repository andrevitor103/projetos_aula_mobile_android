package com.hernanicruz.sqlitedatabase.model;

import java.util.Date;

public class Sensores {
    private int id;
    private String sensor;
    private Date data;

    public int getId() {
        return this.id;
    }

    public String getSensor() {
        return this.sensor;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setSensor(String sensor) {
        this.sensor = sensor;
    }

    public Date getData() {
        return this.data;
    }

    public void setData(Date data) {
        this.data = data;
    }


}
