package com.hernanicruz.sqlitedatabase.api;

public class AppUtil {
    // static permite utilizar sem estaciar a classe
    public final static String TAG = "DB_CRUD";

    public static String versaoDoApp(){

        return "0.001";
    }

}
