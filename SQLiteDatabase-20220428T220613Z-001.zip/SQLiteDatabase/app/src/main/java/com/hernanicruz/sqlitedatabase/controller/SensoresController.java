package com.hernanicruz.sqlitedatabase.controller;

import android.content.ContentValues;
import android.content.Context;
import android.util.Log;

import com.hernanicruz.sqlitedatabase.api.AppUtil;
import com.hernanicruz.sqlitedatabase.dasource.AppDataBase;
import com.hernanicruz.sqlitedatabase.datamodel.SensorDataModel;
import com.hernanicruz.sqlitedatabase.model.Sensores;

import java.util.Date;
import java.util.List;

public class SensoresController extends AppDataBase implements ICrud<Sensores>
{
    ContentValues dadosDoObj;

    public SensoresController(Context context) {
        super(context);
        Log.d(AppUtil.TAG, "SensoresController: conectado");
    }

    @Override
    public boolean incluir(Sensores obj) {
        dadosDoObj = new ContentValues();
        dadosDoObj.put(SensorDataModel.SENSOR, obj.getSensor());
        dadosDoObj.put(SensorDataModel.DATA, String.valueOf(new Date()));
        return insert(SensorDataModel.TABELA, dadosDoObj);
    }

    @Override
    public boolean alterar(Sensores obj) {
        return false;
    }

    @Override
    public boolean deletar(int id) {
        return false;
    }

    @Override
    public List listar() {
        return null;
    }
}
