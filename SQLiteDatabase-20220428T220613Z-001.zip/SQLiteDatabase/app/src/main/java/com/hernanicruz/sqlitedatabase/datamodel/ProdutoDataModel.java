package com.hernanicruz.sqlitedatabase.datamodel;

// extends AppDataBase implements ICrud<Produto>
public class ProdutoDataModel {
}
