package com.hernanicruz.sqlitedatabase.controller;


// extends AppDataBase implements ICrud<Cliente>
public class ClienteController {
}
