package com.hernanicruz.sqlitedatabase.datamodel;

public class ClienteDataModel {
}
