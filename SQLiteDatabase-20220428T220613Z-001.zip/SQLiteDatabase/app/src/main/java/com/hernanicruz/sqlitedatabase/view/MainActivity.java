package com.hernanicruz.sqlitedatabase.view;

import androidx.appcompat.app.AppCompatActivity;

import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.Toast;

import com.hernanicruz.sqlitedatabase.R;
import com.hernanicruz.sqlitedatabase.controller.SensoresController;
import com.hernanicruz.sqlitedatabase.datamodel.SensorDataModel;
import com.hernanicruz.sqlitedatabase.model.Sensores;

import java.util.Iterator;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ListView listaSensores;
    String sensores = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SensorManager mSensorManger = (SensorManager)
                getSystemService(SENSOR_SERVICE);
        List<Sensor> lista = mSensorManger.getSensorList(Sensor.TYPE_ALL);
        Iterator<Sensor> iterator = lista.iterator();
        SensoresController sensorController = new SensoresController(getApplicationContext());

        Sensores sensorModel = new Sensores();

        while(iterator.hasNext()) {
            Sensor sensor = iterator.next();
            sensores += " - " + sensor.getName() + '\n';

            Log.d("SENSORES", "Sensores: " + sensores);
            sensorModel.setSensor(sensores);
            sensorController.incluir(sensorModel);
        }
        Toast.makeText(getApplicationContext(), sensores, Toast.LENGTH_LONG).show();
    }
}
